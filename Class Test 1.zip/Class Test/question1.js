
let genColor = () =>{
    let ColorText = document.querySelector("#text").value;
    
    document.documentElement.style.backgroundColor = ColorText;


}